package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.model.Admin;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;


import java.io.IOException;

public class AdminFormController {
    private Admin admin ;
    public Stage stage;
    private Scene scene;
    private Parent root;
    private Alert alert;

    @FXML
    public void initialize() {
        admin = new Admin() ;
    }

    @FXML
    private TextField username1 ;

    @FXML
    private PasswordField password ;

    public void onExitButtonClick(){
        alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to close the application?");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }
    @FXML
    public void onLogInButtonClick(ActionEvent event) throws IOException {

        if(username1.getText().isEmpty() || password.getText().isEmpty()){
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Please fill all blank fields");
            alert.showAndWait();
        }
        else{
            if (!admin.logIn(username1.getText(), password.getText())) {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Wrong Credentials");
                alert.setHeaderText(null);
                alert.setContentText("Username or Password incorrect. \nPlease enter correct username and password");
                alert.showAndWait();
            }else{
                root = FXMLLoader.load(getClass().getResource("adminPage.fxml")) ;
                stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
                scene = new Scene(root, 800, 500) ;
                stage.setTitle("adminInfo");
                stage.setScene(scene) ;
                stage.show();
            }
        }


    }

    @FXML
    public void onSignUpButtonClick(ActionEvent event) throws IOException{
        root = FXMLLoader.load(getClass().getResource("surveyCreatorForm.fxml")) ;
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("Survey Creator Sign UP");
        stage.setScene(scene) ;
        stage.show();
    }

}
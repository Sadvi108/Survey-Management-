package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.model.Survey;
import com.example.surveymanagementsystem.holders.SurveyHolder;
import com.example.surveymanagementsystem.holders.SurveyListHolder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class AdminPageController {
    private ArrayList<Survey> surveys ;
    @FXML
    private TextField searchSID ;
    @FXML
    private TableView<Survey> surveyTable ;
    @FXML
    private TableColumn<Survey, String> surveyId ;
    @FXML
    private TableColumn<Survey, String> surveyTitle ;
    @FXML
    private TableColumn<Survey, String> creatorName ;
    public Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    public void initialize() {
        SurveyListHolder su = SurveyListHolder.getInstance();
        surveys = su.getSurveys() ;

        surveyId.setCellValueFactory(new PropertyValueFactory<Survey, String>("surveyId"));
        surveyTitle.setCellValueFactory(new PropertyValueFactory<Survey, String>("surveyTitle"));
        creatorName.setCellValueFactory(new PropertyValueFactory<Survey, String>("creatorName"));
        surveyTable.getItems().setAll(surveys) ;
    }
    @FXML
    public void onEditSurveyButtonClick(ActionEvent event) throws IOException {
        String id = searchSID.getText() ;
        int i = 0 ;
        for (Survey su: surveys){
            if(su.getSurveyId().equals(id)){
                SurveyHolder holder = SurveyHolder.getInstance();
                holder.setSurvey(su);

                surveys.remove(i) ;
                SurveyListHolder h1 = SurveyListHolder.getInstance() ;
                h1.setSurveys(surveys);
                root = FXMLLoader.load(getClass().getResource("editSurveyForm.fxml")) ;
                stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;


                scene = new Scene(root, 800, 500) ;
                stage.setTitle("Survey Creator Sign UP");

                stage.setScene(scene) ;
                stage.show();
                return;
            }
            i++ ;
        }
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect id");
        alert.setHeaderText(null);
        alert.setContentText("ID does not exist.");
        alert.showAndWait() ;



    }
    @FXML
    public void onReportSurveyButtonClick(){
        String id = searchSID.getText() ;
        int i = 0 ;
        for (Survey su: surveys){
            if(su.getSurveyId().equals(id)){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Report");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to report this Survey?");
                int finalI = i;
                alert.showAndWait().ifPresent(response -> {
                    if (response == ButtonType.OK) {
                        surveys.remove(finalI) ;
                        surveyTable.getItems().setAll(surveys) ;
                    }
                });

                return;
            }
            i++ ;
        }


    }
    @FXML
    public void onDeleteSurveyButtonClick(){
        String id = searchSID.getText() ;
        int i = 0 ;
        for (Survey su: surveys){
            if(su.getSurveyId().equals(id)){
                surveys.remove(i) ;
                surveyTable.getItems().setAll(surveys) ;

                return;
            }
            i++ ;
        }
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect id");
        alert.setHeaderText(null);
        alert.setContentText("ID does not exist.");
        alert.showAndWait() ;

    }
    @FXML
    public void onGenerateButtonClick(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("surveyForm.fxml")) ;
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("adminInfo");
        stage.setScene(scene) ;
        stage.show();
    }
    @FXML
    public void onExitButtonClick(){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to close the application?");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }

}

package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.model.Question;
import com.example.surveymanagementsystem.model.Survey;
import com.example.surveymanagementsystem.holders.SurveyHolder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class CreateQuestionForCreatorController {
    public Survey survey ;
    public Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private TextArea polar ;
    @FXML
    private TextArea MCQ ;
    @FXML
    private TextField option1 ;
    @FXML
    private TextField option2 ;
    @FXML
    private TextField option3 ;
    @FXML
    private TextField option4 ;
    @FXML
    private TextArea openEnd ;

    @FXML
    private TextArea surveyTitle1 ;
    @FXML
    private TextArea surveyTitle2 ;
    @FXML
    private TextArea surveyTitle3 ;

    public void onExitButtonClick(){
        System.exit(0);
    }
    public void initialize() {
        survey = SurveyHolder.getInstance().getSurvey();
        surveyTitle1.setText(survey.getSurveyTitle());
        surveyTitle2.setText(survey.getSurveyTitle());
        surveyTitle3.setText(survey.getSurveyTitle());


    }

    @FXML
    public void onAddMCQ(ActionEvent event)throws IOException{
        if(MCQ.getText().isEmpty() || option1.getText().isEmpty() || option2.getText().isEmpty() ||option3.getText().isEmpty() ||option4.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Details ");
            alert.setHeaderText(null);
            alert.setContentText("Please Fill all details.");
            alert.showAndWait() ;
        }
        Question a = new Question("q113", 3, MCQ.getText(), survey.getSurveyId(), option1.getText()) ;
        survey.addQuestion(a);
        SurveyHolder.getInstance().setSurvey(survey);


        root = FXMLLoader.load(getClass().getResource("creatreSurveyForCreator.fxml")) ;

        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("Edit survey");
        stage.setScene(scene) ;
        stage.show();

    }
    @FXML
    public void onAddPolar(ActionEvent event)throws IOException{


        root = FXMLLoader.load(getClass().getResource("creatreSurveyForCreator.fxml")) ;

        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("Edit survey");
        stage.setScene(scene) ;
        stage.show();
    }
    @FXML
    public void onAddOpenEnded(ActionEvent event)throws IOException{
        root = FXMLLoader.load(getClass().getResource("creatreSurveyForCreator.fxml")) ;

        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("Edit survey");
        stage.setScene(scene) ;
        stage.show();
    }



}

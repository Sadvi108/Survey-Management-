package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.holders.SurveyCreatorHolder;
import com.example.surveymanagementsystem.holders.SurveyHolder;
import com.example.surveymanagementsystem.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class CreateSurveyForCreatorController {
   private Survey survey ;

    public void setSurvey(Survey survey) {
        this.survey = survey;
    }

    public Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField sqid ;

    @FXML
    private TableView<Question> qTable ;
    @FXML
    private TextField surveyTitle ;
    @FXML
    private TableColumn<Question, String> qId ;
    @FXML
    private TableColumn<Question, String> qText;
    @FXML
    private TableColumn<Question, String> qPosition ;

    @FXML
    public void initialize() {
        this.survey = new Survey("1211", "Enter Survey Title", SurveyCreatorHolder.getInstance().getCreato().getFirstName(), "cs0101") ;
        SurveyHolder.getInstance().setSurvey(survey);
        surveyTitle.setText(survey.getSurveyTitle());

        qId.setCellValueFactory(new PropertyValueFactory<Question, String>("QuestionId"));
        qText.setCellValueFactory(new PropertyValueFactory<Question, String>("QuestionText"));
        qPosition.setCellValueFactory(new PropertyValueFactory<Question, String>("QuestionPosition"));
        ArrayList<Question> a = survey.getQuestions() ;
        qTable.getItems().setAll(a);
    }

    @FXML
    public void onDeleteQuestionClick(ActionEvent event){
        String id = sqid.getText() ;
        int i = 0 ;
        for (Question su: survey.getQuestions()){
            if(su.getQuestionId().equals(id)){
                survey.deleteQuestion(su) ;
                ArrayList<Question> a = survey.getQuestions() ;
                qTable.getItems().setAll(a);
                return;
            }
            i++ ;
        }
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect id");
        alert.setHeaderText(null);
        alert.setContentText("ID does not exist.");
        alert.showAndWait() ;
    }
    @FXML
    public void onBackToAdminPage(ActionEvent event) throws IOException{
        SurveyCreator a = SurveyCreatorHolder.getInstance().getCreato() ;
        this.survey.setSurveyTitle(surveyTitle.getText());
        a.addSurvey(survey);
        SurveyCreatorHolder.getInstance().setCreator(a);

        root = FXMLLoader.load(getClass().getResource("SurveyCreatorPage.fxml")) ;

        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("adminInfo");
        stage.setScene(scene) ;
        stage.show();
    }





    @FXML
    public void onAddQuestionClicked(ActionEvent event) throws IOException{
        SurveyHolder.getInstance().setSurvey(survey);
        root = FXMLLoader.load(getClass().getResource("createQuestionForCreator.fxml")) ;
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("adminInfo");
        stage.setScene(scene) ;
        stage.show();


    }


}

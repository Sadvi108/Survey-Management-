package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.model.Question;
import com.example.surveymanagementsystem.model.Survey;
import com.example.surveymanagementsystem.holders.SurveyListHolder;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class SurveyApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        SurveyListHolder holder = SurveyListHolder.getInstance() ;
        ArrayList<Survey> surveys = new ArrayList<>() ;
        Survey su = new Survey("111", "Which is best method", "Neon", "sc12") ;
        su.addQuestion(new Question("q121", 0, "Are you married", "121", "yes"));
        su.addQuestion(new Question("q122", 1, "Do believe we can achive our goals ", "121", "yes"));
        su.addQuestion(new Question("q123", 2, "Are you a Musician.?", "121", "no"));
        surveys.add(su) ;
        surveys.add(new Survey("121", "Which is best method", "Neon", "sc12")) ;
        surveys.add(new Survey("122", "Which is best method", "Alpha", "sc13")) ;
        surveys.add(new Survey("123", "Which is best method", "Beta", "sc14")) ;

        holder.setSurveys(surveys);


        FXMLLoader fxmlLoader = new FXMLLoader(SurveyApplication.class.getResource("adminForm.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 650, 400);
        stage.setTitle("Welcome");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.holders.SurveyCreatorHolder;
import com.example.surveymanagementsystem.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class SurveyCreatorPageController {
    private SurveyCreator creator ;
    public Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private TextField searchSID ;
    @FXML
    private TableView<Survey> surveyTable ;


    @FXML
    private TableColumn<Survey, String> creatorName;
    @FXML
    private TableColumn<Survey, String> surveyTitle ;
    @FXML
    private TableColumn<Survey, String> surveyId ;

    @FXML
    public void initialize() {
       creator =  SurveyCreatorHolder.getInstance().getCreato();

        surveyId.setCellValueFactory(new PropertyValueFactory<Survey, String>("surveyId"));
        surveyTitle.setCellValueFactory(new PropertyValueFactory<Survey, String>("surveyTitle"));
        creatorName.setCellValueFactory(new PropertyValueFactory<Survey, String>("creatorName"));
        surveyTable.getItems().setAll(creator.getSurveys()) ;

    }

    public void onExitButtonClick(){
        System.exit(0);
    }
    @FXML
    public void onCreateNewSurveyClick(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("creatreSurveyForCreator.fxml")) ;
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("Survey Creator");
        stage.setScene(scene) ;
        stage.show();
    }
    @FXML
    public void onDeleteSurvey(ActionEvent event) throws IOException{
        String id = searchSID.getText() ;
        int i = 0 ;
        for (Survey su: creator.getSurveys()){
            if(su.getSurveyId().equals(id)){
                creator.deleteSurvey(su) ;
                surveyTable.getItems().setAll(creator.getSurveys()) ;
                return;
            }
            i++ ;
        }
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect id");
        alert.setHeaderText(null);
        alert.setContentText("ID does not exist.");
        alert.showAndWait() ;
    }

  
}

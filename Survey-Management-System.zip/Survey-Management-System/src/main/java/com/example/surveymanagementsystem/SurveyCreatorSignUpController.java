package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.model.Survey;
import com.example.surveymanagementsystem.model.SurveyCreator;
import com.example.surveymanagementsystem.holders.SurveyCreatorHolder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class SurveyCreatorSignUpController {
    public Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField SCId ;
    @FXML
    private TextField username ;
    @FXML
    private TextField password ;
    @FXML
    private ComboBox gender ;
    @FXML
    private TextArea firstName;
    @FXML
    private TextArea lastName ;
    @FXML
    private TextArea phoneNumber ;
    @FXML
    private TextArea faculty ;
    @FXML
    private TextArea Address ;

    public void onExitButtonClick(){
        System.exit(0);
    }
    @FXML
    public void onSignUpButtonClick(ActionEvent event) throws IOException {
        if(SCId.getText().isEmpty() || username.getText().isEmpty()|| password.getText().isEmpty()||firstName.getText().isEmpty()||lastName.getText().isEmpty()||phoneNumber.getText().isEmpty()||faculty.getText().isEmpty()||Address.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Details ");
            alert.setHeaderText(null);
            alert.setContentText("please, Fill all fields ");
            alert.showAndWait();
            return;
        }

        SurveyCreatorHolder.getInstance().setCreator(new SurveyCreator(SCId.getText(), username.getText(), password.getText(), firstName.getText(), lastName.getText(), faculty.getText(), "male",Address.getText(), phoneNumber.getText(), new ArrayList<Survey>() ));

        root = FXMLLoader.load(getClass().getResource("SurveyCreatorPage.fxml")) ;
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("Survey Creator");
        stage.setScene(scene) ;
        stage.show();
    }


}

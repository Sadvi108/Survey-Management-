package com.example.surveymanagementsystem;

import com.example.surveymanagementsystem.model.Survey;
import com.example.surveymanagementsystem.holders.SurveyListHolder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class SurveyFormController {
    private ArrayList<Survey> surveys ;


    public Stage stage;
    private Scene scene;
    private Parent root;



    @FXML
    private TableView<Survey> surveyTable ;

    @FXML
    private TableColumn<Survey, String> SCId ;
    @FXML
    private TableColumn<Survey, String> creatorName;
    @FXML
    private TableColumn<Survey, String> surveyTitle ;
    @FXML
    private TableColumn<Survey, String> surveyId ;

    @FXML
    public void initialize() {
        SurveyListHolder su = SurveyListHolder.getInstance();
        surveys = su.getSurveys() ;

        SCId.setCellValueFactory(new PropertyValueFactory<Survey, String>("SCId"));
        surveyId.setCellValueFactory(new PropertyValueFactory<Survey, String>("surveyId"));
        surveyTitle.setCellValueFactory(new PropertyValueFactory<Survey, String>("surveyTitle"));
        creatorName.setCellValueFactory(new PropertyValueFactory<Survey, String>("creatorName"));
        surveyTable.getItems().setAll(surveys) ;


    }

    @FXML
    public void onExitButtonClick(){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to close the application?");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }

    @FXML
    public void onBackToAdminPage(ActionEvent event) throws IOException{

        root = FXMLLoader.load(getClass().getResource("adminPage.fxml")) ;

        stage = (Stage) ((Node)event.getSource()).getScene().getWindow() ;
        scene = new Scene(root, 800, 500) ;
        stage.setTitle("adminInfo");
        stage.setScene(scene) ;
        stage.show();
    }



}

package com.example.surveymanagementsystem.holders;

import com.example.surveymanagementsystem.model.SurveyCreator;

public final class SurveyCreatorHolder {
    private SurveyCreator creator ;
    private final static SurveyCreatorHolder INSTANC = new SurveyCreatorHolder() ;

    private SurveyCreatorHolder(){}

    public static SurveyCreatorHolder getInstance() {

        return INSTANC;
    }

    public void setCreator(SurveyCreator u) {
        this.creator = u;
    }

    public SurveyCreator getCreato() {
        return this.creator;
    }
}

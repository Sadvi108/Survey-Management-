package com.example.surveymanagementsystem.holders;

import com.example.surveymanagementsystem.model.Survey;

public final class SurveyHolder {
    private Survey survey ;
    private final static SurveyHolder INSTANC = new SurveyHolder() ;

    private SurveyHolder(){}

    public static SurveyHolder getInstance() {

        return INSTANC;
    }

    public void setSurvey(Survey u) {
        this.survey = u;
    }

    public Survey getSurvey() {
        return this.survey;
    }
}

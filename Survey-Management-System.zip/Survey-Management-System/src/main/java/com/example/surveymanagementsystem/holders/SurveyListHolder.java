package com.example.surveymanagementsystem.holders;

import com.example.surveymanagementsystem.model.Survey;

import java.util.ArrayList;

public final class SurveyListHolder {
    private ArrayList<Survey> surveys;
    private final static SurveyListHolder INSTANC = new SurveyListHolder() ;

    private SurveyListHolder(){}

    public static SurveyListHolder getInstance() {
        return INSTANC;
    }

    public void setSurveys(ArrayList<Survey> u) {
        this.surveys = u;
    }

    public ArrayList<Survey> getSurveys() {
        return this.surveys;
    }
}

package com.example.surveymanagementsystem.model;
import org.mindrot.jbcrypt.BCrypt;

import java.io.*;

public class Admin {
    private String username ;
    private  String pasword ;
    private String filename ;

    public Admin() {
        this.filename = "admin.dat" ;
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length == 2) {
                    this.username = parts[0] ;
                    this.pasword = parts[1] ;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveCredentialsToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            bw.write(username + " " + pasword);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void resetPassword(String newPassword) {
        resetUsernameAndPassword(this.username, newPassword);
    }

    public void resetUsername(String ursername) {
        resetUsernameAndPassword(username, this.pasword);
    }

    public void resetUsernameAndPassword(String username, String password) {
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        this.pasword = hashedPassword ;
        this.username = username ;
        saveCredentialsToFile();
    }
    public boolean logIn(String username, String password) {
        if(this.username.equals(username)){
            return this.pasword != null && BCrypt.checkpw(password, this.pasword);
        }
       return false ;
    }




}

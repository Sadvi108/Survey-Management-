package com.example.surveymanagementsystem.model;

public class Question {
    private String QuestionId ;
    private int QuestionPosition ;
    private String QuestionText;
    private String SurveyId ;
    private String answer ;

    public Question(String questionId, int questionPosition, String questionType, String surveyId, String answer) {
        QuestionId = questionId;
        QuestionPosition = questionPosition;
        QuestionText = questionType;
        SurveyId = surveyId;
        this.answer = answer ;
    }

    public void setQuestionId(String questionId) {
        QuestionId = questionId;
    }

    public void setQuestionPosition(int questionPosition) {
        QuestionPosition = questionPosition;
    }

    public void setQuestionText(String questionText) {
        QuestionText = questionText;
    }

    public void setSurveyId(String surveyId) {
        SurveyId = surveyId;
    }

    public String getQuestionId() {
        return QuestionId;
    }

    public int getQuestionPosition() {
        return QuestionPosition;
    }

    public String getQuestionText() {
        return QuestionText;
    }

    public String getSurveyId() {
        return SurveyId;
    }
    public boolean checkAnswer(String answer){
        return  this.answer.equals(answer) ;
    }
}

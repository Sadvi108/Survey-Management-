package com.example.surveymanagementsystem.model;

import java.util.ArrayList;
import java.util.List;

public class Survey {
    private String surveyId ;
    private String SCId ;
    private String surveyTitle ;
    private String creatorName ;

    public void setSurveyTitle(String surveyTitle) {
        this.surveyTitle = surveyTitle;
    }

    private ArrayList<Question> questions ;

    public Survey(String surveyId, String surveyTitle, String creatorName , String SCId ){
        this.surveyId = surveyId ;
        this.surveyTitle = surveyTitle ;
        this.creatorName = creatorName ;
        this.SCId = SCId ;
        this.questions = new ArrayList<>();
    }
    public ArrayList<Question> getQuestions(){
        return this.questions ;
    }
    public void addQuestion(Question question){
        this.questions.add(question) ;
    }
    public boolean deleteQuestion(Question question){
       return this.questions.remove(question) ;
    }

    public boolean updateQuestion(Question question){
        return this.questions.remove(question) ;
    }

    public String getSurveyTitle() {
        return surveyTitle;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public String getSurveyId() {
        return surveyId;
    }
    public String getSCId() {
        return this.SCId;
    }
}

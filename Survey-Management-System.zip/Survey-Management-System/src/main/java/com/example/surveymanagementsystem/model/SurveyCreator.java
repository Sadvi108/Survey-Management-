package com.example.surveymanagementsystem.model;

import java.util.List;

public class SurveyCreator {
    private String SCId ;
    private String username ;
    private String password ;
    private String firstName ;
    private String lastName ;
    private String faculty ;
    private String gender ;
    private String emailAddress ;
    private String phoneNumber ;
    private List<Survey> surveys ;

    public SurveyCreator(String SCId, String username, String password, String firstName, String lastName, String faculty, String gender, String emailAddress, String phoneNumber, List<Survey> surveys) {
        this.SCId = SCId;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.faculty = faculty;
        this.gender = gender;
        this.emailAddress = emailAddress;
        this.phoneNumber = phoneNumber;
        this.surveys = surveys ;
    }

    public String getSCId() {
        return SCId;
    }

    public void setSCId(String SCId) {
        this.SCId = SCId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Survey> getSurveys() {
        return surveys;
    }

    public void addSurvey(Survey survey) {
        this.surveys.add(survey) ;
    }
    public void deleteSurvey(Survey survey) {
        this.surveys.remove(survey) ;
    }
}

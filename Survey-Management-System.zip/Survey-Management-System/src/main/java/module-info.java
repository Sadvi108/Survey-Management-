module com.example.surveymanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires jbcrypt;

    opens com.example.surveymanagementsystem to javafx.fxml;
    exports com.example.surveymanagementsystem;
    exports com.example.surveymanagementsystem.model;
    opens com.example.surveymanagementsystem.model to javafx.fxml;
    exports com.example.surveymanagementsystem.holders;
    opens com.example.surveymanagementsystem.holders to javafx.fxml;
}